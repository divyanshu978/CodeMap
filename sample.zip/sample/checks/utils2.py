def add(a, b):
    return a + b

print("Sum:", add(2, 3))
