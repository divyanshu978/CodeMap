package add

func Add(x,y int) int{
	return x+y;
}