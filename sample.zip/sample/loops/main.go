package main

import "fmt"

func main() {
	fmt.Println("Learning Loops.............")
	// for loop!
	for i := 1; i <= 10; i++ {
		fmt.Print(i, " ")
	}
	//altternative for while loop!
	//for condition:
	// for condition{
	// }
	
}
